# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from dateutil.relativedelta import relativedelta
from datetime import date




class facultydata(models.Model):
    _name = 'school.faculty'
    _description = 'faculty detail'
    _rec_name = 'first_name'

    full_name = fields.Char(string='Full Name', compute='_compute_facultyfullname')
    first_name = fields.Char(help='Students first name')
    last_name = fields.Char(help='Students last name')
    dob = fields.Date(help='Students dob')
    Fac_age=fields.Integer(string="Age" , compute="_compute_FAculty_age" )
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('other', 'Other')])
    # address=fields.Text(help='Students address')
    Qualification = fields.Char(help='Students Qualification')
    faculty_id = fields.Many2one('school.standard', string='Standard')
    subject_faculty = fields.Many2many('school.subject', string='Subject')
    joining_date = fields.Date()
    Experince = fields.Char(string='Faculty Experince', compute='_compute_Experince')

    # valodation error in faculty dob if user selected the date the preseent time
    @api.constrains('dob')
    def _check_dob(self):
        if self.dob:
            if self.dob > date.today():
                raise ValidationError(_('You cannot  select dob beacuse the selected dob is not valid.'))

    # Making THE Faculty Full name on the basis of first_name and last_name
    @api.depends('first_name', 'last_name')
    def _compute_facultyfullname(self):
        for rec in self:
            if rec.first_name and rec.last_name:
                # rec.full_name = f"{rec.first_name} {rec.last_name}"
                rec.full_name = rec.first_name + " " + rec.last_name
            else:
                rec.full_name = ""

    # Counting Faculty Experince on the basis of joinning date
    @api.depends('joining_date')
    def _compute_Experince(self):
        self.Experince = False
        for rec in self:
            rec.Experince = relativedelta(date.today(), rec.joining_date).years

    # Counting Faculty Age on the basis of dob
    @api.depends('dob')
    def _compute_FAculty_age(self):
        self.Fac_age = False
        for rec in self:
            rec.Fac_age = relativedelta(date.today(), rec.dob).years





















    # first_name(char), last_name(char), dob(date), address(text)
    # Qualification(char)

    # standard=fields.Selection()
    # value2 = fields.Float(compute="_value_pc", store=True)
    # description = fields.Text()

    # fields.(Char, Float, Integer, Text, Html, Boolean, Monetary, Date, Datetime, Selection, Many2one, One2many, Many2many)
    # 'sale.order', string="Test", store=True/False, compute="method_name", domain, readonly=True/False, help="message"
    # tree, form, search, kanban, graph, pivot

