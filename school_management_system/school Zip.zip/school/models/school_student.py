# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError ,  UserError

class StudentData(models.Model):
    _name = 'school.student'
    _description = 'student data'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'Student_first_name'

    full_name=fields.Char(string='Full Name',compute='_compute_fullname' )
    Student_first_name=fields.Many2one('school.admission',string='First Name')
    last_name=fields.Char(related="Student_first_name.last_name",string="Last Name")
    dob=fields.Date(help='Students dob')
    age=fields.Char(help='the age of students',string='age',compute='_compute_age')
    std_id = fields.Many2one('school.standard')
    sdfre_ids = fields.One2many('school.admission','get_student_reference')
    get_admin_student_address=fields.Char(string="Student Address")




    @api.onchange('Student_first_name')
    def get_student_address(self):
        if self.Student_first_name:
            self.get_admin_student_address = self.Student_first_name.admin_student_address

    @api.onchange('Student_first_name')
    def get_student_address(self):
        if self.Student_first_name:
            self.get_admin_student_address = self.Student_first_name.admin_student_address

# calculate the age of student according to dob

    @api.depends('dob')
    def _compute_age(self):
        self.age=False
        for rec in self:
            rec.age = relativedelta(date.today(),rec.dob).years



# This Constraints Is called the python constraints this is used for the validation
# this is for validation in which if student selected dob and time when they are taking admission then they cant be able to fill the form
    @api.constrains('dob')
    def _check_dob(self):
        if self.dob:
            if self.dob > date.today():
                raise UserError(_('You cannot  select dob beacuse the selected dob is not valid.'))


# Write the full name on the basisi of firstname + lastname= fullname
    @api.depends('Student_first_name', 'last_name')
    def _compute_fullname(self):
        for rec in self:
            if rec.Student_first_name.first_name and rec.last_name:
                # rec.full_name = f"{rec.first_name} {rec.last_name}"
                  rec.full_name = rec.Student_first_name.first_name + " " + rec.last_name
            else:
                rec.full_name = ""


# object Button putted in School_student_views
    def action_test(self):
        print("Button Clicked !!!!!!!")
        return {
            'effect': {
                'fadeout': 'slow',
                'message': 'You Have Successfully Get The Student Detail',
                'type': 'rainbow_man',
            }
        }

    # def action_view_details(self):
    #     self.ensure_one()
    #     return {
    #         'name': _('Admission Detailss'),
    #         'view_mode': 'list,form',
    #         'res_model': 'school.admission',
    #         'domain': [('student_full_name', '=', self.full_name)],
    #         'res_id': self.id,
    #         'view_id': False,
    #         'type': 'ir.actions.act_window',
    #         'context': {'default_student': self.id}
    #     }












    # @api.onchange('first_name')
    # def onchange_gender(self):
    #     if self.first_name:
    #         if self.first_name_gender:
    #             self.gender=self.first_name.gender
    # standard=fields.Selection()
    # value2 = fields.Float(compute="_value_pc", store=True)
    # description = fields.Text()

    # fields.(Char, Float, Integer, Text, Html, Boolean, Monetary, Date, Datetime, Selection, Many2one, One2many, Many2many)
    # 'sale.order', string="Test", store=True/False, compute="method_name", domain, readonly=True/False, help="message"
    # tree, form, search, kanban, graph, pivot
#   
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100

