# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class timetableschedule(models.Model):
    _name = 'timetable.schedule'
    _description = 'Timetable schedule'
    _rec_name = 'day'

    time=fields.Selection([('7-8','7:00-8:00'),('8-9','8:00-9:00'),('9-10','9:00-10:00'),('10-11','10:00-11:00'),('11-12','11:00-12:00'),('12-1','12:00-01:00')])
    fac=fields.Many2one('school.faculty')
    sub=fields.Many2one('school.subject')
    day=fields.Selection([('monday','Monday'),('tuesday','Tuesday'),('Wensday','Wensday'),('Thursday','Thursday'),('friday','Friday'),('saturday','Saturday')])
    timetable_master_id = fields.Many2one('timetable.master')

