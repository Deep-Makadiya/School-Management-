# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class timetable(models.Model):
    _name = 'timetable.master'
    _description = 'Timetable master'
    _rec_name = 'get_faculty'

    standard_timetable_master=fields.Many2one('school.standard',string="standard")
    timetable_schedule_ids = fields.One2many('timetable.schedule','timetable_master_id')
    get_faculty=fields.Many2one('school.faculty', string = "Faculty")
    get_faculty_from_subject=fields.Many2many('school.subject', string="Subject")


    # Geting the faculty subject on the basis of the faculty name
    @api.onchange('get_faculty')
    def get_subject_faculty(self):
        if self.get_faculty:
            self.get_faculty_from_subject = self.get_faculty.subject_faculty
