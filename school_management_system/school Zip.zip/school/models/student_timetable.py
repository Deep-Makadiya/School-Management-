# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class Studenttimetable(models.Model):
    _name = 'school.timetable'
    _description = 'Student Timetable data'
    _rec_name = 'teacher_time'

    Period=fields.Selection([('1','1'),('2','2'),('3','3'),('4','4'),('5','5')])
    # subject=fields.Many2one('school.subject')
    # faculty=fields.Char(help='faculty')
    teacher_time=fields.Many2one('school.faculty')
    gender=fields.Selection([('male','Male'),('female','Female'),('other','Other')])
    subjects = fields.Many2many('school.subject')


# By faculty name give the faculty gender by selecting the faculty name
    @api.onchange('teacher_time')
    def onchange_faculty_gender(self):
        self.gender=self.teacher_time.gender

# Geting the faculty subject on the basis of the faculty name
    @api.onchange('teacher_time')
    def get_subject_faculty(self):
        if self.teacher_time:
            self.subjects = self.teacher_time.subject_faculty


# Cron Function Call(Scheduler action Function call)
    def remove_scheduler_student_timetable(self):
        print("Kem Palty!!!!!!!")



