# -*- coding: utf-8 -*-

from . import school_student
from . import school_faculty
from . import school_subject
from . import school_admission
from . import student_timetable
from .import teacher_timetable
from . import school_standard
from . import timetable_master
from . import timetable_schedule
